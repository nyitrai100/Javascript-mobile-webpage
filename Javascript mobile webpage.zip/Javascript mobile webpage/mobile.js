const phones = [
  
    {
     Brand: "Apple",
     Name: "Iphone 12pro",
     Memory: "512GB",
     Cost: 1149,
     Color: "Gold",
     Ext: "iphone12pro.jpeg",
    },
    {
        Brand: "Apple",
        Name: "Iphone 12pro",
        Memory: "512GB",
        Cost: 1149,
        Color: "Silver",
        Ext: "iphone12pro.jpeg",
       },

    {
        Brand: "Apple",
        Name: "Iphone 12pro",
        Memory: "512GB",
        Cost: 1149,
        Color: "Gray",
        Ext: "iphone12pro.jpeg",
       },

    {
        Brand: "Apple",
        Name: "Iphone SE 2020",
        Memory: "64GB",
        Cost: 349,
        Color: "Red",
        Ext: "iphoneSE2020.jpeg",
        },

        {
        Brand: "Apple",
        Name: "Iphone SE 2020",
        Memory: "64GB",
        Cost: 349,
        Color: "White",
        Ext: "iphoneSE2020.jpeg",
        },
         {
        Brand: "Apple",
        Name: "Iphone 13 mini",
        Memory: "256GB",
        Cost: 729,
        Color: "Blue",
        Ext: "iphone13Mini.jpeg",
        },
        {
        Brand: "Apple",
        Name: "Iphone 13 mini",
        Memory: "256GB",
        Cost: 729,
        Color: "White",
        Ext: "iphone13Mini.jpeg",
        },
        {
        Brand: "Apple",
        Name: "Iphone 13 mini",
        Memory: "256GB",
        Cost: 729,
        Color: "Pink",
        Ext: "iphone13Mini.jpeg",
         },
        {
        Brand: "Apple",
        Name: "Iphone 13 mini",
        Memory: "256GB",
        Cost: 729,
        Color: "Black",
        Ext: "iphone13Mini.jpeg",
                    },

    {
        Brand: "Google",
        Name: "Pixel 6A",
        Memory: "128GB",
        Cost: 399,
        Color: "Green",
        Ext: "googlepixel6a.jpeg",
        },

        {
        Brand: "Google",
        Name: "Pixel 6A",
        Memory: "128GB",
        Cost: 399,
        Color: "White",
        Ext: "googlepixel6a.jpeg",
        },
             
        {
        Brand: "Google",
        Name: "Pixel 6A",
        Memory: "128GB",
        Cost: 399,
        Color :"Black",
        Ext: "googlepixel6a.jpeg",
        },
        

    {
        Brand: "Google",
        Name: "Pixel 6Pro",
        Memory: "256GB",
        Cost: 749,
        Color: "Black",
        Ext: "googlepixal6pro.jpeg",
        },
        
    {
        Brand: "Motorola",
        Name: "G82",
        Memory: "128GB",
        Cost: 249,
        Color: "Gray",
        Ext: "MotorolaG82.jpeg",
        },
    
    {
        Brand: "Motorola",
        Name: "Moto E30",
        Memory: "32GB",
        Cost: 89,
        Color: "Gray",
        Ext: "MotorolaE30.jpeg",
        },
        {
        Brand: "Motorola",
        Name: "Moto E30",
        Memory: "32GB",
        Cost: 89,
        Color: "Blue",
        Ext: "MotorolaE30.jpeg",
            },

     {
        Brand: "Samsung",
        Name: "Galaxy S22 Plus",
        Memory: "128GB",
        Cost: 949,
        Color: "Green",
        Ext: "samsunggalaxys22plus.jpeg",
        },

     {
        Brand: "Samsung",
        Name: "Galaxy S22 Plus",
        Memory: "128GB",
        Cost: 949,
        Color: "Black",
        Ext: "samsunggalaxys22plus.jpeg",
        },

         {
        Brand: "Samsung",
        Name: "Galaxy S22 Plus",
        Memory: "128GB",
        Cost: 949,
        Color: "White",
        Ext: "samsunggalaxys22plus.jpeg",
        },

         {
        Brand: "Samsung",
        Name: "Galaxy S22 Plus",
        Memory: "128GB",
        Cost: 949,
        Color: "Pink",
        Ext: "samsunggalaxys22plus.jpeg",
        },

    {
        Brand: "Samsung",
        Name: "Galaxy A13",
        Memory: "64GB",
        Cost: 129,
        Color: "Black",
        Ext: "samsunggalaxya13.jpeg",
        },
     {
        Brand: "Samsung",
        Name: "Galaxy A13",
        Memory: "64GB",
        Cost: 129,
        Color: "White",
        Ext: "samsunggalaxya13.jpeg",
        },
            
    {
        Brand: "Nokia",
        Name: "105",
        Memory: "4MB",
        Cost: 25,
        Color: "Blue",
        Ext: "nokia105.jpg",
        },
    
     {
        Brand: "Nokia",
        Name: "105",
        Memory: "4MB",
        Cost: 25,
        Color: "Black",
        Ext: "nokia105.jpg",
        },
     {
        Brand: "Nokia",
        Name: "105",
        Memory: "4MB",
        Cost: 25,
        Color: "Pink",
        Ext: "nokia105.jpg",
        },

    
    ]